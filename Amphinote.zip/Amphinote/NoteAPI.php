<?php 

require_once("DB.php");

function POST(){

	$db = new DB("localhost", "amphinote", "root", "");

if(isset($_POST['description'])&&isset($_POST['titre'])&&isset($_POST['userid'])&&isset($_POST['matiere'])){
    $path="uploads/";
    $name = $_FILES['imageupload']['name'];//Name of the File
    $temp = $_FILES['imageupload']['tmp_name'];
    if(move_uploaded_file($temp, $path . $name)){
    	$description=$_POST['description'];
		$titre=$_POST['titre'];
		$userid=$_POST['userid'];
		$matiere=$_POST['matiere'];
		$image= $path . $name;
		$query ="INSERT INTO `note` (`id`, `image`, `description`,`titre`, `userid`,`matiere`) VALUES (NULL, '$image', '$description','$titre', '$userid','$matiere'); ";
		$db->query($query);
        echo json_encode($db->query("SELECT * FROM `note` where titre = '$titre' AND userid = '$userid'"));
        return http_response_code(200);
    }else{
        return http_response_code(400);
    }
}

elseif (isset($_POST['aime'])&&isset($_POST['userid'])&&isset($_POST['noteid'])) {
	$userid=$_POST['userid'];
	$noteid=$_POST['noteid'];
	$aime = $_POST['aime'];
	$query="INSERT INTO aime (`userid`, `noteid`, `aime`) VALUES($userid, $noteid, '$aime') ON DUPLICATE KEY UPDATE `aime`='$aime'";
	$db->query($query);
	$db->query("UPDATE note n SET aime = (SELECT COUNT(*) FROM aime a WHERE n.id = a.noteid AND a.aime=1)");
    echo json_encode($db->query("SELECT aime FROM `aime` where noteid = '$noteid' AND userid = '$userid'")->aime);
	return http_response_code(200);
}

else {	
		return http_response_code(400);
	}
}


function GET(){


	$db = new DB("localhost", "amphinote", "root", "");

	$query ="SELECT * FROM `note` where 1 ";
	
	if(isset($_GET['userid'])&&isset($_GET['noteid'])){
		$userid=$_GET['userid'];
		$noteid=$_GET['noteid'];
		if (json_encode($db->query("SELECT aime FROM `aime` where noteid = '$noteid' AND userid = '$userid'"))=='false'){			
				return -1;
		}else{
			return json_encode(($db->query("SELECT aime FROM `aime` where noteid = '$noteid' AND userid = '$userid'")->aime));
		}
	}
	if(isset($_GET['userid'])) {
		$userid=$_GET['userid'];
		$query .= "AND userid = '$userid' ";
	}
	if(isset($_GET['titre'])) {
		$titre=$_GET['titre'];
		$query .= "AND titre = '$titre' ";
	}
	if(isset($_GET['aime'])) {
		$aime=$_GET['aime'];
		$query .= "AND aime = '$aime' ";
	}
	if (isset($_GET['matiere'])) {
		$matiere=$_GET['matiere'];
		$query .= "AND matiere = '$matiere' ";
	}
	if (isset($_GET['search'])) {
		$search=$_GET['search'];
		$query .= "AND description LIKE '%$search%' OR
		titre LIKE '%$search%' OR
		matiere LIKE '%$search%' ";
	}
	if(isset($_GET['filter'])&&isset($_GET['order'])){	
		$filter=$_GET['filter'];
		$order=$_GET['order'];
		$query .="ORDER BY $filter $order";
	}
	if (json_encode($db->queryNote($query))=='false'){			
				return http_response_code(400);}
	return json_encode($db->queryNote($query));

}
?>
