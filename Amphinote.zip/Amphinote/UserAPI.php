<?php 

require_once("DB.php");

function GET(){
$db = new DB("localhost", "amphinote", "root", "");
$query ="SELECT username,age,email,lastname,id,photo FROM `user` where 1 ";

	if(isset($_GET['username'])) {
		$username=$_GET['username'];
		$query .= "AND username = '$username' ";
	}
	else {	
		//si ya r
	}

	if(isset($_GET['password'])) {
		$password=$_GET['password'];
		$query .= "AND password = '$password' ";

	}
	else {	
		//si ya r
	}

	if(isset($_GET['id'])) {
		$id=$_GET['id'];
		$query .= "AND id = '$id' ";
	}
	else {	
		//si ya r
	}

	if(isset($_GET['age'])) {
		$age=$_GET['age'];
		$query .= "AND age = '$age' ";
	}
	else {	
		//si ya r
	}

	if(isset($_GET['email'])) {
		$email=$_GET['email'];
		$query .= "AND email = '$email' ";
	}
	else {	
		//si ya r
	}

		if(isset($_GET['lastname'])) {
		$lastname=$_GET['lastname'];
		$query .= "AND lastname = '$lastname' ";
	}
	else {	
		//si ya r
	}

	return json_encode($db->query($query));

}

function POST(){
$db = new DB("localhost", "amphinote", "root", "");

	if(isset($_POST['username']) && isset($_POST['password']) && isset($_POST['age']) && isset($_POST['email']) && isset($_POST['lastname']) ) {
		$email=$_POST['email'];
		$query="SELECT * FROM `user` where email = '$email'";
		if (!($db->query($query)==false)) {
			return http_response_code(403);
		}else{
		$username=$_POST['username'];
		$password=$_POST['password'];
		$age=$_POST['age'];
		$lastname=$_POST['lastname'];
		$query ="INSERT INTO `user` (`id`, `username`, `lastname`, `email`, `age`, `password`) VALUES (NULL, '$username', '$lastname', '$email', '$age', '$password'); ";
		$db->query($query);
		echo json_encode($db->query("SELECT * FROM `user` where email = '$email'"));
		return http_response_code(200);
	}
}	
	elseif (file_exists($_FILES['imageupload']['tmp_name']) && is_uploaded_file($_FILES['imageupload']['tmp_name']) && isset($_POST['id'])) 
		{
			$id=$_POST['id'];
    		$path="profil/";
    		$name = $_FILES['imageupload']['name'];//Name of the File
    		$temp = $_FILES['imageupload']['tmp_name'];
    		if(move_uploaded_file($temp, $path . $name)){
    			$image= $path . $name;
    			$query = "UPDATE user SET photo = '$image' WHERE id='$id';";
    			$db->query($query);
    			echo json_encode($db->query("SELECT username,age,email,lastname,id,photo FROM `user` where id='$id';"));
				return http_response_code(200);
		}
	}
	else {	
		return http_response_code(400);
	}
}


function PATCH(){
$db = new DB("localhost", "amphinote", "root", "");
$id= trim($_SERVER['PATH_INFO'],'/');
$input = json_decode(file_get_contents('php://input'),true);
    if(isset($input['email'])) {
        $email=$input['email'];
        $query="SELECT * FROM user where email = '$email'";
        if (!($db->query($query)==false)) {
            return http_response_code(403);
        }else{

        $query ="UPDATE user SET email = '$email' WHERE id=$id;";
        $db->query($query);
        echo json_encode($db->query("SELECT * FROM user where id = '$id'"));
        return http_response_code(200);
    }
}
elseif(isset($input['password'])){
		$password=$input['password'];
		$query ="UPDATE user SET password = '$password' WHERE id=$id;";
        $db->query($query);
        echo json_encode($db->query("SELECT * FROM user where id = '$id'"));
        return http_response_code(200);
}
}


 ?>