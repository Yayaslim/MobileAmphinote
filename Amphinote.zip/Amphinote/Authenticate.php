<?php  

require_once("DB.php");

function authenticate(){
	$usermail = $_SERVER['PHP_AUTH_USER'];
	$password = $_SERVER['PHP_AUTH_PW'];
	$db = new DB("localhost", "amphinote", "root", "");
	$query="SELECT * FROM `user` where email = '$usermail' AND password = '$password'  ";
	if($db->query($query)==false){
		return false;

}
	else{
		return true;
}
}
?>