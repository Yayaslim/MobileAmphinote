<?php 

require_once("Authenticate.php");
require_once("DB.php");
require_once("UserAPI.php");
header('Content-type: application/json');

	if ($_SERVER['REQUEST_METHOD'] == "GET") {
		if(authenticate()==true){
			echo GET();
		}
		else {
			http_response_code(405);
		}
	}elseif($_SERVER['REQUEST_METHOD'] == "POST") {
    	POST();
    }elseif($_SERVER['REQUEST_METHOD'] == "PATCH") {
    		PATCH();
    }
   else{
   	 http_response_code(401);
   }

?>