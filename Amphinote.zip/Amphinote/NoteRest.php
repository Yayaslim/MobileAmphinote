<?php 

require_once("Authenticate.php");
require_once("DB.php");
require_once("NoteAPI.php");

	if ($_SERVER['REQUEST_METHOD'] == "GET") {
		echo GET();
	}
	elseif($_SERVER['REQUEST_METHOD'] == "POST") {
    	POST();
    }
   else{
   	 return http_response_code(400);
   }

?>