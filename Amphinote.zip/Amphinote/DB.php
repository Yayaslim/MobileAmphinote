<?php
class DB {
        private $pdo;
        public function __construct($host, $dbname, $username, $password) {
                $pdo = new PDO('mysql:host='.$host.';dbname='.$dbname.';charset=utf8', $username, $password);
                $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $this->pdo = $pdo;
        }
        public function query($query, $params = array()) {
                $statement = $this->pdo->prepare($query);
                $statement->execute($params);
                if (explode(' ', $query)[0] == 'SELECT') {
                        if ($statement->rowCount()==1) {
                                $data = $statement->fetch(PDO::FETCH_OBJ);
                        }
                        else if($statement->rowCount()==0){
                                $data=false; 
                        }
                        else{
                        $data = $statement->fetchAll(PDO::FETCH_OBJ);       
                        }
                return $data;
                }
        }
                public function queryNote($query, $params = array()) {
                $statement = $this->pdo->prepare($query);
                $statement->execute($params);
                if (explode(' ', $query)[0] == 'SELECT') {
                        if ($statement->rowCount()>0) {
                                $data = $statement->fetchAll(PDO::FETCH_OBJ);
                        }
                        else{
                                $data=false; 
                        }
                return $data;
                }
        }
}